<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Xplor Canada</title>
  <link rel="stylesheet" href="css/style2.css">
</head>
<body>
  <section class="container">
    <div class="login">
      <h1>Login to Xplor</h1>
      <form action="verify.php" method="post">
		User Name:<br>
		<input type="text" name="username" id="username"><br><br>
		Password:<br>
		<input type="password" name="password" id="password"><br><br>
		<input type="submit" name="submit" value="Login">
	</form>
    </div>

  </section>
</body>
</html>
