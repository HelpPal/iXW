<?php 
session_start(); 
if(!$_SESSION['logged']){ 
    header("Location: login_page.php"); 
    exit; 
} 
echo 'Welcome, '.$_SESSION['username']; 
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
      <title>Xplor Canada</title>
      <link href="css/style1.css" rel="stylesheet" type="text/css" />
	  <link href="css/style.css" rel="stylesheet" type="text/css" />
	  <script src="./js/jquery-1.10.2.js"></script>
	  <style>
      #map_canvas {
        width: 500px;
        height: 400px;
      }
    </style>
   </head>
   <body>
      <div id="container">
         <div id="header">
            <h1>Xplor Canadian</h1>
         </div>
         <div id="sub_header"></div>
         <div id="main_content_top"></div>
         <div id="main_content">
            <div class="content">
               <h2>Manage Clients</h2>
			   <div id="inline_content">
					<form action="">
						<label>Category </label>
						<select name="category_menu" id="category_menu">
							<option value="0" selected>All</option>
						</select>
						<script type="text/javascript">
							$(document).ready(function(){
							var url = "get_category.php" ;
							$.getJSON(url, function(data) {
								$.each(data, function(index, data) {
									$('#category_menu').append("<option value='"+data.id+"'>"+data.name+"</option>");
									
								});
							});
							});	
						</script>
						
						<label name="lblBusiness" id="lblBusiness">Business </label>
						<script type="text/javascript">
							$(document).ready(function(){
							
							var url = "get_businessname.php?" ;
							url = url + window.location.search.substr(1);
							$.getJSON(url, function(data) {
								$('[id$=lblBusiness]').text(data[0].name);
							});
							});	
						</script>

						

						<script type="text/javascript">
							$('#category_menu').on('change', function (e) {
								var valueSelected = this.value;
								$('#tablebody').empty();
								var prmstr = window.location.search.substr(1);

								var url = 'search_position.php?&allow=2&' + prmstr + "&kind=" + valueSelected;
								$.getJSON(url, function(data) {
									$.each(data, function(index, data) {
										if (data.allow == '1')
										{
											$('#tablebody').append("<tr><td>"+data.id+"</td><td>"+data.name+"</td><td>"+data.latitude+"</td><td>"+data.longitude+"</td><td>"+data.call+"</td><td>"+data.des+"</td><td id='gen_form'><input class='check-allx' type='checkbox' checked " + "onClick=setStatus(this,0," + data.id + ")></td><td><a style='cursor:pointer;' onClick='editPosition(this)'>Edit</a></td><td><a style='cursor:pointer;' onClick='deletePosition(this)'>Delete</a></td></tr>");
										}
										else
										{
											$('#tablebody').append("<tr><td>"+data.id+"</td><td>"+data.name+"</td><td>"+data.latitude+"</td><td>"+data.longitude+"</td><td>"+data.call+"</td><td>"+data.des+"</td><td id='gen_form'><input class='check-allx' type='checkbox' " + "onClick=setStatus(this,1," + data.id + ")></td><td><a style='cursor:pointer;' onClick='editPosition(this)'>Edit</a></td><td><a style='cursor:pointer;' onClick='deletePosition(this)'>Delete</a></td></tr>");
										}									
									});
								});
							});
						</script>
					</form>
			   </div>
				<div>
				  <table id="background-image" width="400px">
                     <thead>
                        <tr>
                           <th scope="col" width="5%">ID</th>
                           <th scope="col" width="10%">Name</th>
                           <th scope="col" width="10%">Latitude</th>
                           <th scope="col" width="10%">longitude</th>
						   <th scope="col" width="10%">Call</th>
                           <th scope="col" width="10%">Description</th>
                           <th scope="col">Allow</th>
                        </tr>
                     </thead>
					 <tfoot>
						<tr id="newTr" style="display:none">
							<td colspan="9">
								<label>Name </label><input type="text" size="20" id="txtName">
								<label>Latitude </label><input type="text" size="10" id="txtLat">
								<label>Longitude </label><input type="text" size="10" id="txtLong"><br>
								<label>Call </label><input type="text" size="20" id="txtCall">
								<label>Description </label><input type="text" size="50" id="txtDescription">
								<input type="button" onClick="AddPosition()" id="btnAdd" value="Add Position">
							</td>

							<script language="javascript">
								function AddPosition(flag)
								{
									var kindElement = document.getElementById("category_menu"); 
									var kind = kindElement.options[kindElement.selectedIndex].value;
									if (kind==0)
									{
										alert("Please select kind of position.") ;
									}
									else
									{
										if (window.XMLHttpRequest) 
										{
											self.XMLHttp = new XMLHttpRequest();
										}
										else if (window.ActiveXObject) 
										{
											self.XMLHttp = new ActiveXObject("Microsoft.XMLHTTP");
										}
										var prmstr = window.location.search.substr(1);
				

										self.XMLHttp.open("POST", "add_position.php");
										self.XMLHttp.onreadystatechange = handlerFunction;
										self.XMLHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
										self.XMLHttp.send(prmstr+"&name="+document.getElementById("txtName").value + "&lat=" + document.getElementById("txtLat").value + "&long=" +document.getElementById("txtLong").value+"&kind="+kind+"&call="+document.getElementById("txtCall").value+"&description="+document.getElementById("txtDescription").value);
									}
								}

								function deletePosition(object)
								{
									var str = "Do you want to delete " + object.parentNode.parentNode.cells[1].innerHTML + "'s position?" ;
									if (window.confirm(str))
									{
										if (window.XMLHttpRequest) 
										{
											self.XMLHttp = new XMLHttpRequest();
										}
										else if (window.ActiveXObject) 
										{
											self.XMLHttp = new ActiveXObject("Microsoft.XMLHTTP");
										}

										self.XMLHttp.open("POST", "delete_position.php");
										self.XMLHttp.onreadystatechange = handlerFunction;
										self.XMLHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
										self.XMLHttp.send("id="+object.parentNode.parentNode.cells[0].innerHTML);
									}
								}

								
							</script>
						</tr>
						<tr id="editTr" style="display:none">
							<td colspan="9">
								<input type="hidden" id="txtEditId">
								<label>Name </label><input type="text" size="20" id="txtEditName">
								<label>Latitude </label><input type="text" size="10" id="txtEditLat">
								<label>Longitude </label><input type="text" size="10" id="txtEditLong"><br>
								<label>Category </label><select name="edit_category_menu" id="edit_category_menu">
									</select>
								<script type="text/javascript">
									$(document).ready(function(){
									var url = "get_category.php" ;
									$.getJSON(url, function(data) {
										$.each(data, function(index, data) {
											$('#edit_category_menu').append("<option value='"+data.id+"'>"+data.name+"</option>");
											
										});
									});
									
									});	
								</script>
								<label>Call </label><input type="text" size="20" id="txtEditCall">
								<label>Description </label><input type="text" size="50" id="txtEditDescription"><br>
								<input type="button" onClick="updatePosition()" id="btnAdd" value="Update Position">
							</td>

							<script language="javascript">
								function editPosition(object)
								{
									document.getElementById("editTr").style.display = "" ;
									document.getElementById('newTr').style.display='none' ;
									document.getElementById("txtEditId").value = object.parentNode.parentNode.cells[0].innerHTML ;
									document.getElementById("txtEditName").value = object.parentNode.parentNode.cells[1].innerHTML ;
									document.getElementById("txtEditLat").value = object.parentNode.parentNode.cells[2].innerHTML ;
									document.getElementById("txtEditLong").value = object.parentNode.parentNode.cells[3].innerHTML ;
									document.getElementById("txtEditCall").value = object.parentNode.parentNode.cells[4].innerHTML ;
									document.getElementById("txtEditDescription").value = object.parentNode.parentNode.cells[5].innerHTML ;
								}

								function updatePosition(flag)
								{
									if (window.XMLHttpRequest) 
									{
										self.XMLHttp = new XMLHttpRequest();
									}
									else if (window.ActiveXObject) 
									{
										self.XMLHttp = new ActiveXObject("Microsoft.XMLHTTP");
									}
									
									var kindElement = document.getElementById("edit_category_menu"); 
									var kind = kindElement.options[kindElement.selectedIndex].value;

									self.XMLHttp.open("POST", "update_position.php");
									self.XMLHttp.onreadystatechange = handlerFunction;
									self.XMLHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
									self.XMLHttp.send("id="+document.getElementById("txtEditId").value+"&name="+document.getElementById("txtEditName").value + "&lat=" + document.getElementById("txtEditLat").value + "&long=" +document.getElementById("txtEditLong").value+"&call="+document.getElementById("txtEditCall").value+"&des="+document.getElementById("txtEditDescription").value+"&kind="+kind);
								}
							</script>
						</tr>
						<tr>
							<td colspan="9"><a style='cursor: pointer;' onClick="document.getElementById('newTr').style.display='';document.getElementById('editTr').style.display='none';">Add New Position</a></td>
						</tr>
					 </tfoot>
                     <tbody id="tablebody" width="100%">
                     </tbody>
					 <script type="text/javascript">
						 $(document).ready(function(){
							var prmstr = window.location.search.substr(1);
							var url = "search_position.php?kind=0&allow=2&" + prmstr ;
							
							$.getJSON(url, function(data) {
								$.each(data, function(index, data) {
									if (data.allow == '1')
									{
										$('#tablebody').append("<tr><td>"+data.id+"</td><td>"+data.name+"</td><td>"+data.latitude+"</td><td>"+data.longitude+"</td><td>"+data.call+"</td><td>"+data.des+"</td><td id='gen_form'><input class='check-allx' type='checkbox' checked " + "onClick=setStatus(this,0," + data.id + ")></td><td><a style='cursor:pointer;' onClick='editPosition(this)'>Edit</a></td><td><a style='cursor:pointer;' onClick='deletePosition(this)'>Delete</a></td></tr>");
									}
									else
									{
										$('#tablebody').append("<tr><td>"+data.id+"</td><td>"+data.name+"</td><td>"+data.latitude+"</td><td>"+data.longitude+"</td><td>"+data.call+"</td><td>"+data.des+"</td><td id='gen_form'><input class='check-allx' type='checkbox' " + "onClick=setStatus(this,1," + data.id + ")></td><td><a style='cursor:pointer;' onClick='editPosition(this)'>Edit</a></td><td><a style='cursor:pointer;' onClick='deletePosition(this)'>Delete</a></td></tr>");
									}
								});
							});
							});						  
					  
						var XMLHttp = false;
						var self = this;

						function setStatus(object, nStatus, nId)
						{
							var str = "" ;
							if ( nStatus == 1 )
							{
								str = "Do you want to allow " + (object.parentNode).parentNode.cells[1].innerHTML + "?" ;
							}
							else
							{
								str = "Do you want to disallow " + (object.parentNode).parentNode.cells[1].innerHTML + "?" ;
							}

							if (window.confirm(str))
							{
								if (window.XMLHttpRequest) 
								{
									self.XMLHttp = new XMLHttpRequest();
								}
								else if (window.ActiveXObject) 
								{
									self.XMLHttp = new ActiveXObject("Microsoft.XMLHTTP");
								}

								self.XMLHttp.open("POST", "setPositionStatus.php");
								self.XMLHttp.onreadystatechange = handlerFunction;
								self.XMLHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
								self.XMLHttp.send("st=" + nStatus + "&id=" + nId);
							}	
							else
							{
								if (object.checked)
									object.checked = false ;
								else
									object.checked = true ;
							}
						}

						function handlerFunction() {
						  if (XMLHttp.readyState == 4) {
							//alert(XMLHttp.responseText);
							location.reload();
						  }
						}
					  </script>
                  </table>
               </div>
            </div>
            <div class="menu">
               <div class="menu_title">Main menu</div>
               <ul>
                  <li><a href="index.php" class="menu_link">Home</a></li>
                  <li><a href="index.php" class="menu_link">Manage Client</a></li>
				  <li><a href="category.php" class="menu_link">Manage Category</a></li>
				  <li><a href="business_icon.php" class="menu_link">Business Icon</a></li>
				  <li><a href="admin.php" class="menu_link">Admin</a></li>
               </ul>
               
            </div>
            <div id="clear"></div>
         </div>
         <div align="center">
			<script type="text/javascript" src="js/geocode.js">// <![CDATA[</p>
			<p>// ]]&gt;</script></p>
		 </div>
         <div id="footer"><strong>Copyright &copy; 2014</strong> | <a href="#">Ting.Yang</a></div>
      </div>
   </body>
</html>