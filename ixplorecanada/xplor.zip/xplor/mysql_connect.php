<?php
	$conn = mysql_connect('localhost','q8web_xplor','xplor123');
	
	if(!$conn){
		die('Mysql connection error '.mysql_error());
	}

	$db = mysql_select_db('q8web_xplor_db',$conn);
	if(!$db){
		die('Database selection failed '.mysql_error());
	}
?>